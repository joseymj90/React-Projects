import React from 'react';
import Counters from './components/couters';
import NavBar from './components/navbar';


class App extends React.Component{
  constructor(){
    super();

    this.state = {
        count : [
            { id: 1, value: 4},
            { id: 2, value: 0},
            { id: 3, value: 0},
            { id: 4, value: 0}
        ]
    }

}
handleDelete = (countId) => {
    let count = this.state.count.filter(c => c.id !== countId);
    this.setState({count});
    
}  

handleIncrement = (counter) =>{
    const count = [...this.state.count];
    const index = count.indexOf(counter);
    count[index] = {...counter};
    count[index].value++;
    this.setState({count})

}

handleReset = () => {
   const count = this.state.count.map(c => {
       c.value = 0;
       return c;
   })
   this.setState({count});

}

render(){  
  return (
    <React.Fragment>
      <NavBar totalCounters = {this.state.count.filter(c=>c.value>0).length}/>
      <main className = 'container'>
      <Counters onReset ={this.handleReset}
      count = {this.state.count}
      onIncrement = {this.handleIncrement}
      onDelete = {this.handleDelete} />
      </main>
    </React.Fragment>
  )
}
}

export default App;