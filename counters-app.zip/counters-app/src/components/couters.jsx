import React from 'react';
import Counter from './counter';

class Counters extends React.Component{
     render(){
         const {onReset, onIncrement, onDelete} = this.props;
        return (
            <div>            
                 <button className = 'btn btn-primary'
                 onClick = {onReset} >
                   Reset
                 </button>
            {                
                this.props.count.map(count =>(
                    <Counter key = {count.id} 
                    onDelete = {onDelete}
                    onIncrement = {onIncrement}
                    count = {count} />
                ))
            } 
            </div>
          
        )
    }
}

export default Counters;