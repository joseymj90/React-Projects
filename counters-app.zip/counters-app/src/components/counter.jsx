import React from 'react';


class Counter extends React.Component{
  render(){
    return (
      <div>        
        <span className = {this.formatCountClass()}>{this.formatCount()}</span>
        <button className = 'btn btn-secondary m-2' 
        onClick = {() => this.props.onIncrement(this.props.count)}
        >Increment</button>
        <button className = 'btn btn-danger m-2'
        onClick = {() => this.props.onDelete(this.props.count.id)}>
        Delete
        </button>
       
      </div>
    )
  }
  formatCount(){
    const {value} = this.props.count;
    return value === 0 ? 'zero' : value;
  }

  formatCountClass(){
    let classes = 'badge m-2 badge-';
    return classes += this.props.count.value === 0 ? 'warning' : 'primary';
  }
}

export default Counter;