import React, { useState } from "react";
import useForm from "./useForm";
import validate from "./LoginFormValidationRules";
import { Redirect } from "react-router-dom";
import '../styles.css';

export const data = [
    { id: 1, email: 'josey@gmail.com', password: '123456!A'},
    { id: 2, email: 'johny@gmail.com', password: '123456!B'}
  ]

const Form = props => {
  const { values, errors, handleChange, handleSubmit } = useForm(
    login,
    validate
  );
  const [loggedIn, setLoggedIn] = useState(false);  
  const [people, setPeople] = useState(data);

  function login() {
      people.map(person => {
          if(values.email === person.email && values.password === person.password){
            setLoggedIn(true);
            props.parentCallback(true);
            return <Redirect to="/default" />;
          }else{                  
            return errors.password="Your Email or Password is Invalid";
          }
      })
   
  }

  return (
    <>
      {loggedIn && <Redirect to="/default" />}
      <div className="container">
        <div className='align-items'>
            <h1>Login</h1>
            <form onSubmit={handleSubmit} noValidate>
                <label htmlFor="email">Email Address</label>
                  <input
                    autoComplete="off"
                    className="form-control w-50"
                    type="email"
                    id="email"
                    name="email"
                    onChange={handleChange}
                    value={values.email || ""}
                    required
                  />
                  {errors.email && (
                    <p className="text-danger">{errors.email}</p>
                  )}
                <label htmlFor="password">Password</label>
                  <input
                    autoComplete="off"
                    className="form-control w-50"
                    type="password"
                    id="password"
                    name="password"
                    onChange={handleChange}
                    value={values.password || ""}
                    required
                  />
                {errors.password && (
                  <p className="text-danger">{errors.password}</p>
                )}
              <button type="submit" className="btn btn-primary mt-3">Login</button>
            </form>
            </div>
          </div>
        </>    
  );
};

export default Form;
