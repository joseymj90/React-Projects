import { Component } from 'react';
import Pagination from '../utils/pagination';
import Paginate from '../utils/paginate';
import UsersTable from '../components/users-table';
import _ from 'lodash';
import { SearchBox } from '../search-box/search-box';

class HomeButton extends Component{
  constructor(){
    super();
    this.state = {
      users : [],
      pageSize : 10,
      currentPage : 1,
      sortedColumn : {path : 'title', order : 'asc'},
      searchUsers : ''
     
    };
  }

  componentDidMount(){
    fetch('https://jsonplaceholder.typicode.com/posts')
    .then(response => response.json())
    .then(user => this.setState({users : user}))
  }

  handlePageChange = page => {
    this.setState({currentPage : page});
  }

  handleSort = sortedColumn => {      
    this.setState({sortedColumn});
}

  render(){
    const { pageSize, searchUsers, currentPage, sortedColumn, users: allUsers} = this.state;
    const filtered = allUsers.filter(user => user.title.toLowerCase().includes(searchUsers.toLowerCase()));
    const sorted = _.orderBy(filtered, [sortedColumn.path], [sortedColumn.order] );
    const users = Paginate(sorted, currentPage, pageSize);
   
    return (
      <div>       
        <SearchBox placeholder="search users" handleChange = { e => this.setState({ searchUsers : e.target.value })} />
        <UsersTable
        users = {users}
        sortedColumn = {sortedColumn}
        onSort = {this.handleSort}
        />

        {/* <table className="table table-bordered">
          <tr>
            <th>Id</th>
            <th style={{textAlign: "center"}}>Title</th>
            <th style={{textAlign: "center"}}>Body</th>
          </tr>
          <tbody>
          {monsters.map(monster => (
        <tr key={monster.id}>
          <td>{monster.id}</td>
          <td>{monster.title}</td>
          <td>{monster.body}</td>
        </tr>         
        ))}
            </tbody>
        </table> */}
        
        <Pagination 
        itemsCount = {allUsers.length}
        pageSize = {pageSize} 
        currentPage = {currentPage}
        onPageChange = {this.handlePageChange} />       
      </div>
    );
   
  }
}
export default HomeButton;
