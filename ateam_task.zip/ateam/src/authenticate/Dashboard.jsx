import React from "react";
import HomeButton from "./HomeButton";

function Dashboard() {
  return (
    <div style={{backgroundColor: "lightblue"}}> 
      <h1 style={{textAlign:'center'}}>HOME</h1>
      <HomeButton />
    </div>
  );
}

export default Dashboard;
