import React, { Component } from 'react';
import TableHeader from './table-header';
import UserBody from './user-body';
import '../styles.css';

class UsersTable extends Component {
    columns = [
        {path : 'id' , label : 'Id' },
        {path : 'title' , label : 'Title' },
        {path : 'body' , label : 'Body' }
       
    ]
    render(){
        const {users, onSort, sortedColumn} = this.props;
        return (
            <table className= 'table table-bordered' >
                                <TableHeader columns = {this.columns}
                                sortedColumn = {sortedColumn}
                                onSort = {onSort} 
                                />
                                <UserBody 
                                data = {users} 
                                columns = {this.columns} 
                                />                               
            </table>
        )
    }
}

export default UsersTable;