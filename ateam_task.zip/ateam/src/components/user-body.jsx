import React, { Component } from 'react';
import _ from 'lodash';
import Modal from './modal';

class UserBody extends Component{
    state = {
        modalItem : []
    }
    renderCell = (item , column) => {
        if(column.content) return column.content(item);
        return _.get(item, column.path);
    }

    renderKey = (item , column) => {
        return item._id + (column.path || column.key);
    }

   handleChange = item => {
      const newItem = item;
       this.setState({modalItem : newItem});
   }

    render(){
        const{ data , columns } = this.props;
        return (
            <>
            <tbody>
                {
                     data.map(item => (                       
                            <tr key = {item.id} >{ columns.map(column => (                                
                                 <td key = {this.renderKey(item,column)}>
                                    <a data-toggle="modal" data-target="#exampleModal" onClick={()=>this.handleChange(item)}>
                                    {this.renderCell(item,column)}
                                    </a>
                                 </td>
                        ))
                }
                             </tr>                     
                     ))                                      
                }                
            </tbody>
            {   
                this.state.modalItem.length !== 0 && 
                <Modal newItem = {this.state.modalItem}/>
            }
            </>            
        )
    }
}

export default UserBody;