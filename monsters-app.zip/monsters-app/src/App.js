import { Component } from 'react';
import './App.css';
import { CardList } from './component/cardList/card-list.component';
import { SearchBox } from './component/search-box/search-box.component';

class App extends Component{
  constructor(){
    super();
    this.state = {
      monsters : [],
      searchMonsters : ''
     
    };
  }

  componentDidMount(){
    fetch('https://jsonplaceholder.typicode.com/users')
    .then(response => response.json())
    .then(user => this.setState({monsters:user}))
  }
  render(){
    const { monsters, searchMonsters } = this.state;
    const filteredMonster = monsters.filter(monster => monster.name.toLowerCase().includes(searchMonsters.toLowerCase()));
    return (
      <div className="App">
        <h1>Monsters Roodex</h1>
       <SearchBox placeholder = "search monster" handleChange = { e => this.setState({searchMonsters: e.target.value})} />
       <CardList monsters = {filteredMonster} />

      </div>
    );
   
  }
}
export default App;
